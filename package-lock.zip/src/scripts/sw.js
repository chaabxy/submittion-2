self.addEventListener('push', (event) => {
  console.log('Service worker received push notification:', event);

  let title = 'StoryShare';
  let options = {
    body: 'Ada cerita baru untuk Anda!',
    icon: '/favicon.png',
    badge: '/favicon.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: '1',
    },
    actions: [
      {
        action: 'explore',
        title: 'Lihat Cerita',
        icon: '/favicon.png',
      },
      {
        action: 'close',
        title: 'Tutup',
        icon: '/favicon.png',
      },
    ],
  };

  // Jika ada data dalam push message, gunakan data tersebut
  if (event.data) {
    try {
      const data = event.data.json();
      title = data.title || title;
      options = { ...options, ...data.options };
    } catch (error) {
      console.error('Error parsing push data:', error);
    }
  }

  event.waitUntil(self.registration.showNotification(title, options));
});

// Tambahkan event listener untuk klik pada notifikasi
self.addEventListener('notificationclick', (event) => {
  console.log('Notification click received:', event);

  event.notification.close();

  // Buka aplikasi dan arahkan ke halaman yang sesuai
  if (event.action === 'explore') {
    event.waitUntil(clients.openWindow('/home'));
  } else {
    event.waitUntil(
      clients.matchAll({ type: 'window' }).then((clientList) => {
        // Jika ada jendela yang sudah terbuka, fokuskan
        if (clientList.length > 0) {
          let client = clientList[0];
          for (let i = 0; i < clientList.length; i++) {
            if (clientList[i].focused) {
              client = clientList[i];
            }
          }
          return client.focus();
        }
        // Jika tidak ada jendela yang terbuka, buka yang baru
        return clients.openWindow('/');
      }),
    );
  }
});
