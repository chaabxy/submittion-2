// Fungsi untuk memeriksa apakah Notification API tersedia
export function isNotificationAvailable() {
  return 'Notification' in window;
}

// Fungsi untuk memeriksa apakah izin notifikasi sudah diberikan
export function isNotificationGranted() {
  return Notification.permission === 'granted';
}

// Fungsi untuk memeriksa apakah izin notifikasi ditolak
export function isNotificationDenied() {
  return Notification.permission === 'denied';
}

// Fungsi untuk meminta izin notifikasi
export async function requestNotificationPermission() {
  if (!isNotificationAvailable()) {
    console.error('Notification API tidak didukung di browser ini.');
    return false;
  }

  if (isNotificationGranted()) {
    return true;
  }

  const status = await Notification.requestPermission();

  if (status === 'denied') {
    alert('Izin notifikasi ditolak.');
    return false;
  }

  if (status === 'default') {
    alert('Permintaan izin notifikasi ditutup atau diabaikan.');
    return false;
  }

  return true;
}

// Fungsi untuk mendapatkan langganan push saat ini
export async function getPushSubscription() {
  if (!('serviceWorker' in navigator)) {
    return null;
  }

  try {
    const registration = await navigator.serviceWorker.getRegistration();
    if (!registration) {
      return null;
    }
    return await registration.pushManager.getSubscription();
  } catch (error) {
    console.error('Error getting push subscription:', error);
    return null;
  }
}

// Fungsi untuk memeriksa apakah langganan push saat ini tersedia
export async function isCurrentPushSubscriptionAvailable() {
  return !!(await getPushSubscription());
}

// Fungsi untuk mengkonversi base64 ke Uint8Array (untuk VAPID key)
function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

// Fungsi untuk berlangganan notifikasi
export async function subscribeNotification() {
  if (!(await requestNotificationPermission())) {
    return false;
  }

  if (await isCurrentPushSubscriptionAvailable()) {
    alert('Anda sudah berlangganan notifikasi.');
    return true;
  }

  try {
    const registration = await navigator.serviceWorker.getRegistration();
    if (!registration) {
      alert('Service worker tidak terdaftar. Notifikasi tidak dapat diaktifkan.');
      return false;
    }

    // Gunakan VAPID key dari API (contoh key, ganti dengan key dari API Anda)
    const vapidPublicKey =
      'BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfckjBJuBkr3qBUYIHBQFLXYp5Nksh8U';

    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
    });

    // Di sini Anda bisa mengirim subscription ke server
    console.log('Berhasil berlangganan:', JSON.stringify(subscription));

    alert('Notifikasi berhasil diaktifkan!');
    return true;
  } catch (error) {
    console.error('Error subscribing to push notifications:', error);
    alert('Gagal mengaktifkan notifikasi. Silakan coba lagi nanti.');
    return false;
  }
}

// Fungsi untuk berhenti berlangganan notifikasi
export async function unsubscribeNotification() {
  try {
    const subscription = await getPushSubscription();
    if (!subscription) {
      alert('Anda belum berlangganan notifikasi.');
      return false;
    }

    const result = await subscription.unsubscribe();
    if (result) {
      alert('Notifikasi berhasil dinonaktifkan.');
      return true;
    } else {
      alert('Gagal menonaktifkan notifikasi.');
      return false;
    }
  } catch (error) {
    console.error('Error unsubscribing from push notifications:', error);
    alert('Gagal menonaktifkan notifikasi. Silakan coba lagi nanti.');
    return false;
  }
}

// Fungsi untuk toggle langganan notifikasi
export async function toggleNotificationSubscription() {
  const isSubscribed = await isCurrentPushSubscriptionAvailable();

  if (isSubscribed) {
    const confirmUnsubscribe = confirm('Apakah Anda ingin menonaktifkan notifikasi?');
    if (confirmUnsubscribe) {
      return await unsubscribeNotification();
    }
    return false;
  } else {
    const confirmSubscribe = confirm(
      'Apakah Anda ingin mengaktifkan notifikasi? Anda akan menerima pemberitahuan setiap ada cerita baru.',
    );
    if (confirmSubscribe) {
      return await subscribeNotification();
    }
    return false;
  }
}

// Fungsi untuk mengirim notifikasi (untuk testing)
export function sendTestNotification(title, options = {}) {
  if (!isNotificationGranted()) {
    alert('Izin notifikasi belum diberikan.');
    return false;
  }

  try {
    new Notification(title, {
      body: options.body || 'Ini adalah notifikasi test',
      icon: options.icon || '/favicon.png',
      ...options,
    });
    return true;
  } catch (error) {
    console.error('Error sending notification:', error);
    return false;
  }
}
